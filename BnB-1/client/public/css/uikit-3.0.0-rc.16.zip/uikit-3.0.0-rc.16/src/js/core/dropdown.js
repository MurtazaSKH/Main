import Drop from './drop';

export default {

    extends: Drop

};
